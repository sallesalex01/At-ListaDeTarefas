package br.edu.infnet.listadetarefas.models

data class Tarefas(
    val tarefa: String = "",
    val estado: Boolean = false
)
